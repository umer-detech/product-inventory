<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Product Application</title>
        <link href="<?php echo e(asset('app.css')); ?>" rel="stylesheet">
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.jsx']); ?>
    </head>
    <body class="antialiased">
        <div id="app"></div>
    </body>
</html>
<?php /**PATH /var/www/html/product-inventory/resources/views/welcome.blade.php ENDPATH**/ ?>